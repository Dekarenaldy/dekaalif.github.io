define({
  "_themeLabel": "Plakat",
  "_layout_default": "Privzeta postavitev",
  "_layout_right": "Desna postavitev"
});
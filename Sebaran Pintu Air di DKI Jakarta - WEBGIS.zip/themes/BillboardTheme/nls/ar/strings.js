define({
  "_themeLabel": "موضوع لوحة الإعلانات",
  "_layout_default": "تخطيط افتراضي",
  "_layout_right": "تخطيط صحيح"
});